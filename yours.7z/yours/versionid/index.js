/**
 * ��¶�ӿڸ��ⲿ
 */
KISSY.add("gallery/yours/1.0/index",function(S, Yours){
    return Yours;
}, {
    requires:["./yours"]
});